(function(document, XSS, $) {
    $(document).on("ready", function() {
        var populatedWorkfrontFieldAutocomplete = $(".workfront-field-autocomplete")[0];
        if ($(populatedWorkfrontFieldAutocomplete).children("coral-autocomplete-item").length > 0) {
            $(".workfront-field-autocomplete").each(function (i, element) {
                var placeholderChildren = $(element).children(".workfront-placeholder");
                if (placeholderChildren.length > 0) {
                    var placeholderChild = placeholderChildren[0];
                    var selectedValue = $(placeholderChild).attr("data-value");
                    placeholderChildren.remove();
                    //$(populatedWorkfrontFieldAutocomplete).children("coral-autocomplete-item").clone().appendTo(element);
                    $(populatedWorkfrontFieldAutocomplete).children("coral-autocomplete-item").clone().each(function (i, e) {
                        if ($(e).attr("value") == selectedValue) {
                            $(e).attr("selected", "");
                        } else {
                            $(e).removeAttr("selected");
                        }
                    }).appendTo(element);
                }
            });
        }
    });
})(document, _g.XSS, Granite.$);