$(window).load(function () {
    $(".foundation-layout-panel-body").on("foundation-contentloaded", function(e) {
        addWorkfrontIcons();
    });
    addWorkfrontIcons();
})

function addWorkfrontIcons() {
    if ($(".foundation-layout-panel-content").has(".cq-damadmin-admin-childpages").length >= 1) {
        var coralCards = $("coral-card");
        if(coralCards.length > 0) {
            for(var i = coralCards.length > 20 ? coralCards.length - (coralCards.length % 20) : 0; i < coralCards.length; i++) {
                coralCard = $(coralCards[i]);
                var path = coralCard.attr('data-foundation-collection-navigator-href');
                if (path != null) {
                    var assetPath = path.startsWith('/assetdetails.html') ? path.substring(18) : path;
                    addCardWorkfrontIcon(assetPath, coralCard);
                }
            }
        }
    }
}

function addCardWorkfrontIcon(assetPath, coralCard) {
    var prefix = $('.foundation-layout-panel-bodywrapper').data("prefix")
	if (prefix == undefined) {
        prefix = "/bin/workfront-tools";
    }
    $.ajax({
        url: prefix+"/workfrontid?asset=" + assetPath,
        dataType: "html",
        success: function(result) {
            if (result != "") {
                var coralCardContent = coralCard.find("coral-card-content");
                if (coralCardContent.length >= 1) {
                    var coralCardContext = coralCardContent.find("coral-card-context");
                    if (coralCardContext.length >= 1) {
                        if (coralCardContext.has(".workfront-icon").length == 0) {
                            coralCardContext.append("<coral-icon icon=\"/apps/hoodoo-digital/workfront-tools/core/clientlibs/assets/resources/workfront-icon.svg\" size=\"M\" style=\"float: right;\" class=\"workfront-icon\">");
                        }
                    }
                }
            }
        }
    })
}
